import React, { useState, useEffect } from 'react';
import LoginScreen from './components/LoginScreen';
import ConferenceRoom from './components/ConferenceRoom';
import { User, Room } from './types';
import { AuthProvider } from './contexts/AuthContext';
import { WebRTCProvider } from './contexts/WebRTCContext';
import { SocketProvider } from './contexts/SocketContext';

function App() {
  const [user, setUser] = useState<User | null>(null);
  const [currentRoom, setCurrentRoom] = useState<Room | null>(null);

  useEffect(() => {
    // Check for stored user session
    const storedUser = localStorage.getItem('rtc_user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
  }, []);

  const handleLogin = (userData: User) => {
    setUser(userData);
    localStorage.setItem('rtc_user', JSON.stringify(userData));
  };

  const handleJoinRoom = (room: Room) => {
    setCurrentRoom(room);
  };

  const handleLeaveRoom = () => {
    setCurrentRoom(null);
  };

  const handleLogout = () => {
    setUser(null);
    setCurrentRoom(null);
    localStorage.removeItem('rtc_user');
  };

  return (
    <div className="min-h-screen bg-gray-900">
      <AuthProvider>
        <SocketProvider>
          <WebRTCProvider>
            {!user ? (
              <LoginScreen onLogin={handleLogin} />
            ) : !currentRoom ? (
              <div className="flex items-center justify-center min-h-screen">
                <div className="bg-gray-800 rounded-lg p-8 shadow-xl max-w-md w-full mx-4">
                  <h2 className="text-2xl font-bold text-white mb-6 text-center">Welcome, {user.name}</h2>
                  <div className="space-y-4">
                    <button
                      onClick={() => handleJoinRoom({ id: 'main', name: 'Main Conference Room' })}
                      className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 px-4 rounded-lg transition-colors"
                    >
                      Join Main Room
                    </button>
                    <button
                      onClick={handleLogout}
                      className="w-full bg-gray-600 hover:bg-gray-700 text-white font-medium py-3 px-4 rounded-lg transition-colors"
                    >
                      Logout
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <ConferenceRoom 
                user={user} 
                room={currentRoom} 
                onLeaveRoom={handleLeaveRoom}
                onLogout={handleLogout}
              />
            )}
          </WebRTCProvider>
        </SocketProvider>
      </AuthProvider>
    </div>
  );
}

export default App;