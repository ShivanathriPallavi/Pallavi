import React, { useState } from 'react';
import { Video, Users, Shield, Palette } from 'lucide-react';
import { User } from '../types';

interface LoginScreenProps {
  onLogin: (user: User) => void;
}

const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim() && email.trim()) {
      onLogin({
        id: Math.random().toString(36).substr(2, 9),
        name: name.trim(),
        email: email.trim(),
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-gray-900 flex items-center justify-center p-4">
      <div className="max-w-4xl w-full grid lg:grid-cols-2 gap-8 items-center">
        {/* Left side - Branding */}
        <div className="text-center lg:text-left space-y-6">
          <div className="flex items-center justify-center lg:justify-start space-x-2">
            <Video className="w-8 h-8 text-blue-400" />
            <h1 className="text-3xl font-bold text-white">ConferenceHub</h1>
          </div>
          
          <p className="text-gray-300 text-xl">
            Professional video conferencing with collaborative tools
          </p>
          
          <div className="space-y-4">
            <div className="flex items-center space-x-3">
              <Video className="w-6 h-6 text-blue-400" />
              <span className="text-gray-300">HD Video Calling & Screen Sharing</span>
            </div>
            <div className="flex items-center space-x-3">
              <Palette className="w-6 h-6 text-green-400" />
              <span className="text-gray-300">Real-time Collaborative Whiteboard</span>
            </div>
            <div className="flex items-center space-x-3">
              <Users className="w-6 h-6 text-purple-400" />
              <span className="text-gray-300">Multi-user File Sharing</span>
            </div>
            <div className="flex items-center space-x-3">
              <Shield className="w-6 h-6 text-red-400" />
              <span className="text-gray-300">Encrypted & Secure</span>
            </div>
          </div>
        </div>

        {/* Right side - Login Form */}
        <div className="bg-gray-800 rounded-2xl p-8 shadow-2xl border border-gray-700">
          <h2 className="text-2xl font-bold text-white mb-6 text-center">Join Conference</h2>
          
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-300 mb-2">
                Full Name
              </label>
              <input
                type="text"
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                placeholder="Enter your full name"
                required
              />
            </div>

            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-2">
                Email Address
              </label>
              <input
                type="email"
                id="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                placeholder="Enter your email"
                required
              />
            </div>

            <button
              type="submit"
              className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-semibold py-3 px-4 rounded-lg transition-all duration-200 transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 focus:ring-offset-gray-800"
            >
              Enter Conference Room
            </button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-sm text-gray-400">
              By joining, you agree to our secure communication protocols
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginScreen;