import React from 'react';
import { 
  Mic, 
  MicOff, 
  Video, 
  VideoOff, 
  Monitor, 
  MessageSquare, 
  Palette, 
  Upload,
  PhoneOff 
} from 'lucide-react';
import { useWebRTC } from '../contexts/WebRTCContext';

interface ToolbarProps {
  onToggleChat: () => void;
  onToggleWhiteboard: () => void;
  onToggleFileShare: () => void;
  showChat: boolean;
  showWhiteboard: boolean;
  showFileShare: boolean;
}

const Toolbar: React.FC<ToolbarProps> = ({
  onToggleChat,
  onToggleWhiteboard,
  onToggleFileShare,
  showChat,
  showWhiteboard,
  showFileShare,
}) => {
  const {
    isAudioEnabled,
    isVideoEnabled,
    isScreenSharing,
    toggleAudio,
    toggleVideo,
    startScreenShare,
    stopScreenShare,
  } = useWebRTC();

  const handleScreenShare = () => {
    if (isScreenSharing) {
      stopScreenShare();
    } else {
      startScreenShare();
    }
  };

  return (
    <div className="bg-gray-800 border-t border-gray-700 px-6 py-4">
      <div className="flex items-center justify-center space-x-2">
        {/* Audio Control */}
        <button
          onClick={toggleAudio}
          className={`p-3 rounded-full transition-colors ${
            isAudioEnabled
              ? 'bg-gray-700 hover:bg-gray-600 text-white'
              : 'bg-red-600 hover:bg-red-700 text-white'
          }`}
          title={isAudioEnabled ? 'Mute microphone' : 'Unmute microphone'}
        >
          {isAudioEnabled ? <Mic className="w-5 h-5" /> : <MicOff className="w-5 h-5" />}
        </button>

        {/* Video Control */}
        <button
          onClick={toggleVideo}
          className={`p-3 rounded-full transition-colors ${
            isVideoEnabled
              ? 'bg-gray-700 hover:bg-gray-600 text-white'
              : 'bg-red-600 hover:bg-red-700 text-white'
          }`}
          title={isVideoEnabled ? 'Turn off camera' : 'Turn on camera'}
        >
          {isVideoEnabled ? <Video className="w-5 h-5" /> : <VideoOff className="w-5 h-5" />}
        </button>

        {/* Screen Share */}
        <button
          onClick={handleScreenShare}
          className={`p-3 rounded-full transition-colors ${
            isScreenSharing
              ? 'bg-blue-600 hover:bg-blue-700 text-white'
              : 'bg-gray-700 hover:bg-gray-600 text-white'
          }`}
          title={isScreenSharing ? 'Stop screen share' : 'Share screen'}
        >
          <Monitor className="w-5 h-5" />
        </button>

        <div className="h-8 w-px bg-gray-600 mx-2" />

        {/* Chat */}
        <button
          onClick={onToggleChat}
          className={`p-3 rounded-full transition-colors ${
            showChat
              ? 'bg-blue-600 hover:bg-blue-700 text-white'
              : 'bg-gray-700 hover:bg-gray-600 text-white'
          }`}
          title="Toggle chat"
        >
          <MessageSquare className="w-5 h-5" />
        </button>

        {/* Whiteboard */}
        <button
          onClick={onToggleWhiteboard}
          className={`p-3 rounded-full transition-colors ${
            showWhiteboard
              ? 'bg-green-600 hover:bg-green-700 text-white'
              : 'bg-gray-700 hover:bg-gray-600 text-white'
          }`}
          title="Toggle whiteboard"
        >
          <Palette className="w-5 h-5" />
        </button>

        {/* File Share */}
        <button
          onClick={onToggleFileShare}
          className={`p-3 rounded-full transition-colors ${
            showFileShare
              ? 'bg-purple-600 hover:bg-purple-700 text-white'
              : 'bg-gray-700 hover:bg-gray-600 text-white'
          }`}
          title="Toggle file sharing"
        >
          <Upload className="w-5 h-5" />
        </button>

        <div className="h-8 w-px bg-gray-600 mx-2" />

        {/* End Call */}
        <button
          className="p-3 rounded-full bg-red-600 hover:bg-red-700 text-white transition-colors"
          title="End call"
        >
          <PhoneOff className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};

export default Toolbar;