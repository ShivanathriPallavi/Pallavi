import React, { useRef, useEffect } from 'react';
import { useWebRTC } from '../contexts/WebRTCContext';
import { Mic, MicOff, Video, VideoOff, User } from 'lucide-react';

const VideoGrid: React.FC = () => {
  const { localStream, remoteStreams, isAudioEnabled, isVideoEnabled } = useWebRTC();
  const localVideoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (localVideoRef.current && localStream) {
      localVideoRef.current.srcObject = localStream;
    }
  }, [localStream]);

  // Demo participants for visual demonstration
  const demoParticipants = [
    { id: '1', name: 'Alice Johnson', audioEnabled: true, videoEnabled: true },
    { id: '2', name: 'Bob Smith', audioEnabled: true, videoEnabled: false },
    { id: '3', name: 'Carol Davis', audioEnabled: false, videoEnabled: true },
  ];

  return (
    <div className="h-full bg-gray-900 rounded-lg overflow-hidden">
      <div className="h-full grid gap-2 p-2">
        {/* Main video area with responsive grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-2 h-full">
          {/* Local video */}
          <div className="relative bg-gray-800 rounded-lg overflow-hidden min-h-48">
            {isVideoEnabled && localStream ? (
              <video
                ref={localVideoRef}
                autoPlay
                muted
                playsInline
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center bg-gray-700">
                <div className="text-center">
                  <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-2">
                    <User className="w-8 h-8 text-white" />
                  </div>
                  <span className="text-white text-sm">You</span>
                </div>
              </div>
            )}
            
            {/* Controls overlay */}
            <div className="absolute bottom-2 left-2 flex space-x-1">
              {isAudioEnabled ? (
                <div className="w-6 h-6 bg-green-600 rounded-full flex items-center justify-center">
                  <Mic className="w-3 h-3 text-white" />
                </div>
              ) : (
                <div className="w-6 h-6 bg-red-600 rounded-full flex items-center justify-center">
                  <MicOff className="w-3 h-3 text-white" />
                </div>
              )}
              {!isVideoEnabled && (
                <div className="w-6 h-6 bg-red-600 rounded-full flex items-center justify-center">
                  <VideoOff className="w-3 h-3 text-white" />
                </div>
              )}
            </div>
            
            {/* Name label */}
            <div className="absolute bottom-2 right-2 bg-black bg-opacity-60 text-white text-xs px-2 py-1 rounded">
              You
            </div>
          </div>

          {/* Demo remote participants */}
          {demoParticipants.map((participant, index) => (
            <div key={participant.id} className="relative bg-gray-800 rounded-lg overflow-hidden min-h-48">
              {participant.videoEnabled ? (
                <div className="w-full h-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
                  <div className="text-center text-white">
                    <div className="w-16 h-16 bg-white bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-2">
                      <User className="w-8 h-8" />
                    </div>
                    <span className="text-sm">{participant.name}</span>
                  </div>
                </div>
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-gray-700">
                  <div className="text-center">
                    <div className="w-16 h-16 bg-gray-600 rounded-full flex items-center justify-center mx-auto mb-2">
                      <User className="w-8 h-8 text-gray-400" />
                    </div>
                    <span className="text-gray-300 text-sm">{participant.name}</span>
                  </div>
                </div>
              )}
              
              {/* Controls overlay */}
              <div className="absolute bottom-2 left-2 flex space-x-1">
                {participant.audioEnabled ? (
                  <div className="w-6 h-6 bg-green-600 rounded-full flex items-center justify-center">
                    <Mic className="w-3 h-3 text-white" />
                  </div>
                ) : (
                  <div className="w-6 h-6 bg-red-600 rounded-full flex items-center justify-center">
                    <MicOff className="w-3 h-3 text-white" />
                  </div>
                )}
                {!participant.videoEnabled && (
                  <div className="w-6 h-6 bg-red-600 rounded-full flex items-center justify-center">
                    <VideoOff className="w-3 h-3 text-white" />
                  </div>
                )}
              </div>
              
              {/* Name label */}
              <div className="absolute bottom-2 right-2 bg-black bg-opacity-60 text-white text-xs px-2 py-1 rounded">
                {participant.name}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default VideoGrid;