import React, { useState, useEffect } from 'react';
import { User, Room, Message } from '../types';
import VideoGrid from './VideoGrid';
import Toolbar from './Toolbar';
import Chat from './Chat';
import Whiteboard from './Whiteboard';
import FileShare from './FileShare';
import ParticipantsList from './ParticipantsList';
import { useWebRTC } from '../contexts/WebRTCContext';

interface ConferenceRoomProps {
  user: User;
  room: Room;
  onLeaveRoom: () => void;
  onLogout: () => void;
}

const ConferenceRoom: React.FC<ConferenceRoomProps> = ({ user, room, onLeaveRoom, onLogout }) => {
  const [showChat, setShowChat] = useState(false);
  const [showWhiteboard, setShowWhiteboard] = useState(false);
  const [showFileShare, setShowFileShare] = useState(false);
  const [showParticipants, setShowParticipants] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);

  const { startCall, stopCall } = useWebRTC();

  useEffect(() => {
    startCall();
    return () => {
      stopCall();
    };
  }, []);

  const handleSendMessage = (content: string) => {
    const message: Message = {
      id: Math.random().toString(36).substr(2, 9),
      userId: user.id,
      userName: user.name,
      content,
      timestamp: new Date(),
      type: 'text',
    };
    setMessages(prev => [...prev, message]);
  };

  const handleLeaveRoom = () => {
    stopCall();
    onLeaveRoom();
  };

  return (
    <div className="h-screen bg-gray-900 flex flex-col">
      {/* Header */}
      <header className="bg-gray-800 border-b border-gray-700 px-6 py-3 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <h1 className="text-xl font-semibold text-white">{room.name}</h1>
          <span className="text-sm text-gray-400">User: {user.name}</span>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setShowParticipants(!showParticipants)}
            className="px-3 py-2 bg-gray-700 hover:bg-gray-600 text-white rounded-lg transition-colors text-sm"
          >
            Participants
          </button>
          <button
            onClick={handleLeaveRoom}
            className="px-3 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors text-sm"
          >
            Leave Room
          </button>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex-1 flex">
        {/* Video Area */}
        <div className="flex-1 flex flex-col">
          <div className="flex-1 p-4">
            {showWhiteboard ? (
              <Whiteboard onClose={() => setShowWhiteboard(false)} />
            ) : (
              <VideoGrid />
            )}
          </div>

          {/* Toolbar */}
          <Toolbar 
            onToggleChat={() => setShowChat(!showChat)}
            onToggleWhiteboard={() => setShowWhiteboard(!showWhiteboard)}
            onToggleFileShare={() => setShowFileShare(!showFileShare)}
            showChat={showChat}
            showWhiteboard={showWhiteboard}
            showFileShare={showFileShare}
          />
        </div>

        {/* Side Panel */}
        {(showChat || showFileShare || showParticipants) && (
          <div className="w-80 bg-gray-800 border-l border-gray-700">
            {showParticipants && (
              <ParticipantsList 
                participants={[]} 
                onClose={() => setShowParticipants(false)} 
              />
            )}
            {showChat && (
              <Chat 
                messages={messages}
                onSendMessage={handleSendMessage}
                currentUser={user}
                onClose={() => setShowChat(false)}
              />
            )}
            {showFileShare && (
              <FileShare onClose={() => setShowFileShare(false)} />
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default ConferenceRoom;