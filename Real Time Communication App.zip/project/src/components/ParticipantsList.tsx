import React from 'react';
import { X, User, Mic, MicOff, Video, VideoOff, Monitor, Crown } from 'lucide-react';
import { Participant } from '../types';

interface ParticipantsListProps {
  participants: Participant[];
  onClose: () => void;
}

const ParticipantsList: React.FC<ParticipantsListProps> = ({ participants, onClose }) => {
  // Demo participants for visual demonstration
  const demoParticipants: Participant[] = [
    {
      id: 'user-1',
      name: 'You (Host)',
      isAudioEnabled: true,
      isVideoEnabled: true,
      isScreenSharing: false,
    },
    {
      id: 'user-2',
      name: 'Alice Johnson',
      isAudioEnabled: true,
      isVideoEnabled: true,
      isScreenSharing: false,
    },
    {
      id: 'user-3',
      name: 'Bob Smith',
      isAudioEnabled: false,
      isVideoEnabled: true,
      isScreenSharing: false,
    },
    {
      id: 'user-4',
      name: 'Carol Davis',
      isAudioEnabled: true,
      isVideoEnabled: false,
      isScreenSharing: true,
    },
  ];

  const allParticipants = participants.length > 0 ? participants : demoParticipants;

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-700">
        <div className="flex items-center space-x-2">
          <User className="w-5 h-5 text-blue-400" />
          <h3 className="text-lg font-semibold text-white">
            Participants ({allParticipants.length})
          </h3>
        </div>
        <button
          onClick={onClose}
          className="p-1 hover:bg-gray-700 rounded-full transition-colors"
        >
          <X className="w-5 h-5 text-gray-400" />
        </button>
      </div>

      {/* Participants List */}
      <div className="flex-1 overflow-y-auto p-4 space-y-2">
        {allParticipants.map((participant, index) => (
          <div
            key={participant.id}
            className="flex items-center justify-between p-3 bg-gray-700 hover:bg-gray-600 rounded-lg transition-colors"
          >
            <div className="flex items-center space-x-3 min-w-0 flex-1">
              {/* Avatar */}
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center flex-shrink-0">
                <User className="w-5 h-5 text-white" />
              </div>
              
              {/* Name and status */}
              <div className="min-w-0 flex-1">
                <div className="flex items-center space-x-2">
                  <p className="text-sm font-medium text-white truncate">
                    {participant.name}
                  </p>
                  {index === 0 && (
                    <Crown className="w-4 h-4 text-yellow-500" title="Host" />
                  )}
                </div>
                {participant.isScreenSharing && (
                  <p className="text-xs text-blue-400 flex items-center space-x-1">
                    <Monitor className="w-3 h-3" />
                    <span>Sharing screen</span>
                  </p>
                )}
              </div>
            </div>

            {/* Controls */}
            <div className="flex items-center space-x-1">
              <div className={`p-1.5 rounded-full ${participant.isAudioEnabled ? 'bg-green-600' : 'bg-red-600'}`}>
                {participant.isAudioEnabled ? (
                  <Mic className="w-3 h-3 text-white" />
                ) : (
                  <MicOff className="w-3 h-3 text-white" />
                )}
              </div>
              <div className={`p-1.5 rounded-full ${participant.isVideoEnabled ? 'bg-green-600' : 'bg-red-600'}`}>
                {participant.isVideoEnabled ? (
                  <Video className="w-3 h-3 text-white" />
                ) : (
                  <VideoOff className="w-3 h-3 text-white" />
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Meeting Info */}
      <div className="p-4 border-t border-gray-700 bg-gray-750">
        <div className="text-sm text-gray-400 space-y-1">
          <p>Meeting Room: Main Conference</p>
          <p>Duration: {new Date().toLocaleTimeString()}</p>
          <p className="flex items-center space-x-1">
            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
            <span>Recording: Active</span>
          </p>
        </div>
      </div>
    </div>
  );
};

export default ParticipantsList;