import React, { useState, useRef } from 'react';
import { X, Upload, Download, File, Image, FileText } from 'lucide-react';
import { FileShare as FileShareType } from '../types';

interface FileShareProps {
  onClose: () => void;
}

const FileShare: React.FC<FileShareProps> = ({ onClose }) => {
  const [files, setFiles] = useState<FileShareType[]>([]);
  const [isDragOver, setIsDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (selectedFiles: FileList | null) => {
    if (selectedFiles) {
      Array.from(selectedFiles).forEach((file) => {
        const fileShare: FileShareType = {
          id: Math.random().toString(36).substr(2, 9),
          name: file.name,
          size: file.size,
          type: file.type,
          url: URL.createObjectURL(file),
          uploadedBy: 'You',
          uploadedAt: new Date(),
        };
        setFiles(prev => [...prev, fileShare]);
      });
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(false);
    handleFileSelect(e.dataTransfer.files);
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getFileIcon = (type: string) => {
    if (type.startsWith('image/')) return <Image className="w-5 h-5" />;
    if (type.includes('text') || type.includes('document')) return <FileText className="w-5 h-5" />;
    return <File className="w-5 h-5" />;
  };

  const downloadFile = (file: FileShareType) => {
    const link = document.createElement('a');
    link.href = file.url;
    link.download = file.name;
    link.click();
  };

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-700">
        <div className="flex items-center space-x-2">
          <Upload className="w-5 h-5 text-purple-400" />
          <h3 className="text-lg font-semibold text-white">File Sharing</h3>
        </div>
        <button
          onClick={onClose}
          className="p-1 hover:bg-gray-700 rounded-full transition-colors"
        >
          <X className="w-5 h-5 text-gray-400" />
        </button>
      </div>

      {/* Upload Area */}
      <div className="p-4">
        <div
          className={`border-2 border-dashed rounded-lg p-6 text-center transition-colors ${
            isDragOver
              ? 'border-purple-500 bg-purple-500 bg-opacity-10'
              : 'border-gray-600 hover:border-purple-500'
          }`}
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onClick={() => fileInputRef.current?.click()}
        >
          <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
          <p className="text-gray-300 mb-1">Drop files here or click to upload</p>
          <p className="text-sm text-gray-500">Support for all file types</p>
          <input
            ref={fileInputRef}
            type="file"
            multiple
            className="hidden"
            onChange={(e) => handleFileSelect(e.target.files)}
          />
        </div>
      </div>

      {/* Files List */}
      <div className="flex-1 overflow-y-auto px-4 pb-4">
        <h4 className="text-sm font-medium text-gray-400 mb-3">Shared Files ({files.length})</h4>
        <div className="space-y-2">
          {files.length === 0 ? (
            <div className="text-center text-gray-500 py-8">
              <File className="w-12 h-12 mx-auto mb-3 text-gray-600" />
              <p>No files shared yet</p>
              <p className="text-sm">Upload files to share with participants</p>
            </div>
          ) : (
            files.map((file) => (
              <div
                key={file.id}
                className="flex items-center justify-between p-3 bg-gray-700 rounded-lg hover:bg-gray-600 transition-colors"
              >
                <div className="flex items-center space-x-3 min-w-0 flex-1">
                  <div className="text-purple-400">
                    {getFileIcon(file.type)}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium text-white truncate">{file.name}</p>
                    <p className="text-xs text-gray-400">
                      {formatFileSize(file.size)} • {file.uploadedBy}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => downloadFile(file)}
                  className="p-2 hover:bg-gray-600 rounded-full transition-colors ml-2"
                  title="Download file"
                >
                  <Download className="w-4 h-4 text-gray-400" />
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default FileShare;